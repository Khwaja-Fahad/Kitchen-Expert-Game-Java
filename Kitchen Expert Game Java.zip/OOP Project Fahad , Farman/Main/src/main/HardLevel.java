package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HardLevel extends JFrame implements ActionListener {

    String questions[][] = new String[10][5];
    String answers[][] = new String[10][2];
    String useranswers[][] = new String[10][1];
    JLabel qno, question;
    JRadioButton opt1, opt2, opt3, opt4;
    ButtonGroup groupoptions;
    JButton next, submit, lifeline;

    public static int timer = 60;
    public static int ans_given = 0;
    public static int count = 0;
    public static int score = 0;

    String name;

    HardLevel() {
        setBounds(50, 0, 1250, 700);
        getContentPane().setBackground(Color.BLACK);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/biryani.png"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 1000, 352);
        add(image);
        
        qno = new JLabel();
        qno.setBounds(50, 350, 50, 30);
        qno.setFont(new Font("Tahoma", Font.PLAIN, 24));
        qno.setForeground(Color.BLUE);
        add(qno);
        
        question = new JLabel();
        question.setBounds(100, 350, 900, 30);
        question.setFont(new Font("Tahoma", Font.PLAIN, 24));
        question.setForeground(Color.BLUE);
        add(question);
        
        questions[0][0] = "Start making your delicious Biryani so what will you add first.?";
        questions[0][1] = "Add and Heat Oil";
        questions[0][2] = "Add and Heat water";
        questions[0][3] = "Add Chicken";
        questions[0][4] = "Add Rice";

        questions[1][0] = "what will you add Secondly? Be carefully in Your choice";
        questions[1][1] = "Fry Onions";
        questions[1][2] = "Add and Heat water";
        questions[1][3] = "Fry Onion and Add Tomato";
        questions[1][4] = "All of these";

        questions[2][0] = "Make sure you don't spoil your Biryani in 3rd step";
        questions[2][1] = "Add spices with Tomato";
        questions[2][2] = "Fry Onions";
        questions[2][3] = "Dum and serve";
        questions[2][4] = "None of these";

        questions[3][0] = "Add one more Item in 4th step? for more delicious Biryani";
        questions[3][1] = "Add potato";
        questions[3][2] = "Add chicken";
        questions[3][3] = "Layer Rice";
        questions[3][4] = "None of these";

        questions[4][0] = "procede one more step to complete your dish";
        questions[4][1] = "red chilli";
        questions[4][2] = "Black chilli";
        questions[4][3] = "Layer Rice";
        questions[4][4] = "All of these";

        questions[5][0] = "Add a special Item here to make your Biryani more spicy !";
        questions[5][1] = "red chilli";
        questions[5][2] = "black chilli";
        questions[5][3] = "Add Biryani masala";
        questions[5][4] = "None of these";

        questions[6][0] = "Now you can add one optional item ";
        questions[6][1] = "Sprinkle spices";
        questions[6][2] = "Add chicken";
        questions[6][3] = "optin 1 and 2 Both";
        questions[6][4] = "Fry onions";

        questions[7][0] = "Add item which will give a profesional look to your Biryani";
        questions[7][1] = "Garnish";
        questions[7][2] = "Raita and Salad";
        questions[7][3] = "Yakhni";
        questions[7][4] = "Drizzle Saffron Milk";

        questions[8][0] = "Add your second last Item And Finish your work";
        questions[8][1] = "Serve";
        questions[8][2] = "Add Tomato";
        questions[8][3] = "All of these";
        questions[8][4] = "Seal and Dum Cook";

        questions[9][0] = "Finish your last step and become a professional chef ";
        questions[9][1] = "Add Raita now";
        questions[9][2] = "Add Biryani color now";
        questions[9][3] = "Option 2 and 4 Both";
        questions[9][4] = "Garnish and serve your Biryani";
        
        answers[0][1] = "Add and Heat Oil";
        answers[1][1] = "Fry Onions";
        answers[2][1] = "Add spices with Tomato";
        answers[3][1] = "Add chicken";
        answers[4][1] = "Layer Rice";
        answers[5][1] = "Add Biryani masala";
        answers[6][1] = "Sprinkle spices";
        answers[7][1] = "Drizzle Saffron Milk";
        answers[8][1] = "Seal and Dum Cook";
        answers[9][1] = "Garnish and serve your Biryani";
        
        opt1 = new JRadioButton();
        opt1.setBounds(120, 420, 700, 30);
        opt1.setBackground(Color.BLACK);
        opt1.setForeground(Color.BLUE);
        opt1.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt1);
        
        opt2 = new JRadioButton();
        opt2.setBounds(120, 460, 700, 30);
        opt2.setBackground(Color.BLACK);
        opt2.setForeground(Color.BLUE);
        opt2.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt2);
        
        opt3 = new JRadioButton();
        opt3.setBounds(120, 500, 700, 30);
        opt3.setBackground(Color.BLACK);
        opt3.setForeground(Color.BLUE);
        opt3.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt3);
        
        opt4 = new JRadioButton();
        opt4.setBounds(120, 540, 700, 30);
        opt4.setBackground(Color.BLACK);
        opt4.setForeground(Color.BLUE);
        opt4.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt4);
        
        groupoptions = new ButtonGroup();
        groupoptions.add(opt1);
        groupoptions.add(opt2);
        groupoptions.add(opt3);
        groupoptions.add(opt4);
        
        next = new JButton("Next");
        next.setBounds(900, 400, 170, 40);
        next.setFont(new Font("Tahoma", Font.PLAIN, 22));
        next.setBackground(Color.BLACK);
        next.setForeground(Color.BLUE);
        next.setFocusPainted(false);
        next.addActionListener(this);
        add(next);
        
        lifeline = new JButton("50-50 Lifeline");
        lifeline.setBounds(900, 480, 170, 40);
        lifeline.setFont(new Font("Tahoma", Font.PLAIN, 22));
        lifeline.setBackground(Color.BLACK);
        lifeline.setForeground(Color.BLUE);
        lifeline.setFocusPainted(false);
        lifeline.addActionListener(this);
        add(lifeline);
        
        submit = new JButton("Submit");
        submit.setBounds(900, 560, 170, 40);
        submit.setFont(new Font("Tahoma", Font.PLAIN, 22));
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.BLUE);
        submit.setFocusPainted(false);
        submit.addActionListener(this);
        submit.setEnabled(false);
        add(submit);
        
        start(count);
        
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            handleNextButton();
        } else if (ae.getSource() == lifeline) {
            handleLifelineButton();
        } else if (ae.getSource() == submit) {
            handleSubmitButton();
        }
    }

    private void handleNextButton() {
        repaint();
        opt1.setEnabled(true);
        opt2.setEnabled(true);
        opt3.setEnabled(true);
        opt4.setEnabled(true);

        ans_given = 1;
        useranswers[count][0] = (groupoptions.getSelection() != null)
                ? groupoptions.getSelection().getActionCommand()
                : "";

        if (count == 8) {
            next.setEnabled(false);
            submit.setEnabled(true);
        }

        count++;
        start(count);
    }

    private void handleLifelineButton() {
        if (count == 2 || count == 4 || count == 6 || count == 8 || count == 9) {
            opt2.setEnabled(false);
            opt3.setEnabled(false);
        } else {
            opt1.setEnabled(false);
            opt4.setEnabled(false);
        }
        lifeline.setEnabled(false);
    }

    private void handleSubmitButton() {
        ans_given = 1;
        if (groupoptions.getSelection() == null) {
            useranswers[count][0] = "";
        } else {
            useranswers[count][0] = groupoptions.getSelection().getActionCommand();
        }

        for (int i = 0; i < useranswers.length; i++) {
            if (useranswers[i][0].equals(answers[i][1])) {
                score += 10; // Increment score by 10 for each correct answer
            }
        }
        setVisible(false);
       new Score( score);
    }

    private void showScore(String playerName, int playerScore) {
        JOptionPane.showMessageDialog(this, "Player: " + playerName + "\nScore: " + playerScore);
    }

    public void paint(Graphics g) {
        super.paint(g);

        String time = "Time left - " + timer + " seconds";
        g.setColor(Color.RED);
        g.setFont(new Font("Tahoma", Font.BOLD, 25));

        if (timer > 0) {
            g.drawString(time, 850, 400);
        } else {
            g.drawString("Times up!!", 850, 400);
        }

        timer--;

        try {
            Thread.sleep(1000);
            repaint();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (ans_given == 1) {
            ans_given = 0;
            timer = 60;
        } else if (timer < 0) {
            timer = 60;
            opt1.setEnabled(true);
            opt2.setEnabled(true);
            opt3.setEnabled(true);
            opt4.setEnabled(true);

            if (count == 8) {
                next.setEnabled(false);
                submit.setEnabled(true);
            }
            if (count == 9) {
                if (groupoptions.getSelection() == null) {
                    useranswers[count][0] = "";
                } else {
                    useranswers[count][0] = groupoptions.getSelection().getActionCommand();
                }

                for (int i = 0; i < useranswers.length; i++) {
                    if (useranswers[i][0].equals(answers[i][1])) {
                        score += 10;
                    }
                }
                setVisible(false);
                showScore(name, score);
            } else {
                if (groupoptions.getSelection() == null) {
                    useranswers[count][0] = "";
                } else {
                    useranswers[count][0] = groupoptions.getSelection().getActionCommand();
                }
                count++;
                start(count);
            }
        }
    }

    public void start(int count) {
        qno.setText("" + (count + 1) + ". ");
        question.setText(questions[count][0]);
        opt1.setText(questions[count][1]);
        opt1.setActionCommand(questions[count][1]);

        opt2.setText(questions[count][2]);
        opt2.setActionCommand(questions[count][2]);

        opt3.setText(questions[count][3]);
        opt3.setActionCommand(questions[count][3]);

        opt4.setText(questions[count][4]);
        opt4.setActionCommand(questions[count][4]);

        groupoptions.clearSelection();
    }

   
}
