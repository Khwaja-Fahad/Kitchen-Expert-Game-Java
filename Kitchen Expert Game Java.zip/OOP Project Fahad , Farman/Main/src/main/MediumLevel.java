
package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MediumLevel extends JFrame implements ActionListener {
    
    String questions[][] = new String[7][5];
    String answers[][] = new String[7][2];
    String useranswers[][] = new String[7][1];
    JLabel qno, question;
    JRadioButton opt1, opt2, opt3, opt4;
    ButtonGroup groupoptions;
    JButton next, submit, lifeline;
    
    public static int timer = 60;
    public static int ans_given = 0;
    public static int count = 0;
    public static int score = 0;
    

    
    MediumLevel() {
        setBounds(50, 0, 1250, 700);
        getContentPane().setBackground(Color.BLACK);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/cake5.png"));
        JLabel image = new JLabel(i1);
        image.setBounds(380, 10, 365, 365);
        add(image);
        
        qno = new JLabel();
        qno.setBounds(50, 350, 50, 30);
        qno.setFont(new Font("Tahoma", Font.PLAIN, 24));
        qno.setForeground(Color.BLUE);
        add(qno);
        
        question = new JLabel();
        question.setBounds(100, 350, 900, 30);
        question.setFont(new Font("Tahoma", Font.PLAIN, 24));
        question.setForeground(Color.BLUE);
        add(question);
        
        questions[0][0] = "Let's Start to make a sweet dish take your 1st step for the Cake";
        questions[0][1] = "Add Eggs";
        questions[0][2] = "Add water";
        questions[0][3] = "Preheat Oven";
        questions[0][4] = "Option 2 and 3 Both";

        questions[1][0] = "What should be your 2nd step for a sweet Cake?";
        questions[1][1] = "Add chilli";
        questions[1][2] = "Combine Dry Ingredients";
        questions[1][3] = "Add flour";
        questions[1][4] = "All of these";

        questions[2][0] = "Now move further and choose your next Item";
        questions[2][1] = "Cream Butter and Sugar";
        questions[2][2] = "Add flour";
        questions[2][3] = "Add oil";
        questions[2][4] = "None of these";

        questions[3][0] = "So in 4th step what would you like to Add?";
        questions[3][1] = "Add Eggs ";
        questions[3][2] = "Add chicken";
        questions[3][3] = "Vanilla";
        questions[3][4] = "Option 2 and 3 Both";

        questions[4][0] = "procede to 5th step of your dish";
        questions[4][1] = "Now add Cream";
        questions[4][2] = "Add Black chilli";
        questions[4][3] = "All of these";
        questions[4][4] = "Vanilla";

        questions[5][0] = "These is your 2nd last step make sure to add a special Ingredients";
        questions[5][1] = "add milk";
        questions[5][2] = "Now cook All Ingredients";
        questions[5][3] = "Add Dry Ingredients and Milk";
        questions[5][4] = "None of these";

        questions[6][0] = "Let's finish the dish and give it final look";
        questions[6][1] = "Bake and Cool";
        questions[6][2] = "Add Sprinkle";
        questions[6][3] = "Add Chocolate";
        questions[6][4] = "None these";

        answers[0][1] = "Preheat Oven";
        answers[1][1] = "Combine Dry Ingredients";
        answers[2][1] = "Cream Butter and Sugar";
        answers[3][1] = "Add Eggs";
        answers[4][1] = "Vanilla";
        answers[5][1] = "Add Dry Ingredients and Milk";
        answers[6][1] = "Bake and Cool";
        
        opt1 = new JRadioButton();
        opt1.setBounds(120, 420, 700, 30);
        opt1.setBackground(Color.BLACK);
        opt1.setForeground(Color.BLUE);
        opt1.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt1);
        
        opt2 = new JRadioButton();
        opt2.setBounds(120, 460, 700, 30);
        opt2.setBackground(Color.BLACK);
        opt2.setForeground(Color.BLUE);
        opt2.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt2);
        
        opt3 = new JRadioButton();
        opt3.setBounds(120, 500, 700, 30);
        opt3.setBackground(Color.BLACK);
        opt3.setForeground(Color.BLUE);
        opt3.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt3);
        
        opt4 = new JRadioButton();
        opt4.setBounds(120, 540, 700, 30);
        opt4.setBackground(Color.BLACK);
        opt4.setForeground(Color.BLUE);
        opt4.setFont(new Font("Dialog", Font.PLAIN, 20));
        add(opt4);
        
        groupoptions = new ButtonGroup();
        groupoptions.add(opt1);
        groupoptions.add(opt2);
        groupoptions.add(opt3);
        groupoptions.add(opt4);
        
        next = new JButton("Next");
        next.setBounds(900, 400, 170, 40);
        next.setFont(new Font("Tahoma", Font.PLAIN, 22));
        next.setBackground(Color.BLACK);
        next.setForeground(Color.BLUE);
        next.setFocusPainted(false);
        next.addActionListener(this);
        add(next);
        
        lifeline = new JButton("50-50 Lifeline");
        lifeline.setBounds(900, 480, 170, 40);
        lifeline.setFont(new Font("Tahoma", Font.PLAIN, 22));
        lifeline.setBackground(Color.BLACK);
        lifeline.setForeground(Color.BLUE);
        lifeline.setFocusPainted(false);
        lifeline.addActionListener(this);
        add(lifeline);
        
        submit = new JButton("Submit");
        submit.setBounds(900, 560, 170, 40);
        submit.setFont(new Font("Tahoma", Font.PLAIN, 22));
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.BLUE);
        submit.setFocusPainted(false);
        submit.addActionListener(this);
        submit.setEnabled(false);
        add(submit);
        
        start(count);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            repaint();
            opt1.setEnabled(true);
            opt2.setEnabled(true);
            opt3.setEnabled(true);
            opt4.setEnabled(true);
            
            ans_given = 1;
            if (groupoptions.getSelection() == null) {
               useranswers[count][0] = "";
            } else {
                useranswers[count][0] = groupoptions.getSelection().getActionCommand();
            }
            
            if (count == 5) {
                next.setEnabled(false);
                submit.setEnabled(true);
            }
            
            count++;
            start(count);
        } else if (ae.getSource() == lifeline) {
            if (count == 2 || count == 4 || count == 6 ) {
                opt2.setEnabled(false);
                opt3.setEnabled(false);
            } else {
                opt1.setEnabled(false);
                opt4.setEnabled(false);
            }
            lifeline.setEnabled(false);
        } else if (ae.getSource() == submit) {
            ans_given = 1;
            if (groupoptions.getSelection() == null) {
                useranswers[count][0] = "";
            } else {
                useranswers[count][0] = groupoptions.getSelection().getActionCommand();
            }

            for (int i = 0; i < useranswers.length; i++) {
                if (useranswers[i][0].equals(answers[i][1])) {
                    score += 14;
                } else {
                    score += 0;
                }
            }
            setVisible(false);
           new Score( score);
        }
    }
    
    public void paint(Graphics g) {
        super.paint(g);
        
        String time = "Time left - " + timer + " seconds"; // 60
        g.setColor(Color.RED);
        g.setFont(new Font("Tahoma", Font.BOLD, 25));
        
        if (timer > 0) { 
            g.drawString(time, 850, 400);
        } else {
            g.drawString("Times up!!", 850, 400);
        }
        
        timer--; // 59
        
        try {
            Thread.sleep(1000);
            repaint();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        if (ans_given == 1) {
            ans_given = 0;
            timer = 60;
        } else if (timer < 0) {
            timer = 60;
            opt1.setEnabled(true);
            opt2.setEnabled(true);
            opt3.setEnabled(true);
            opt4.setEnabled(true);
            
            if (count == 5) {
                next.setEnabled(false);
                submit.setEnabled(true);
            }
            if (count == 7) { // submit button
                if (groupoptions.getSelection() == null) {
                   useranswers[count][0] = "";
                } else {
                    useranswers[count][0] = groupoptions.getSelection().getActionCommand();
                }
                
                for (int i = 0; i < useranswers.length; i++) {
                    if (useranswers[i][0].equals(answers[i][1])) {
                        score += 14;
                    } else {
                        score += 0;
                    }
                }
                setVisible(false);
               // new Score(name, score);
            } else { // next button
                if (groupoptions.getSelection() == null) {
                   useranswers[count][0] = "";
                } else {
                    useranswers[count][0] = groupoptions.getSelection().getActionCommand();
                }
                count++; // 0 // 1
                start(count);
            }
        }
        
    }
    
    public void start(int count) {
        qno.setText("" + (count + 1) + ". ");
        question.setText(questions[count][0]);
        opt1.setText(questions[count][1]);
        opt1.setActionCommand(questions[count][1]);
        
        opt2.setText(questions[count][2]);
        opt2.setActionCommand(questions[count][2]);
        
        opt3.setText(questions[count][3]);
        opt3.setActionCommand(questions[count][3]);
        
        opt4.setText(questions[count][4]);
        opt4.setActionCommand(questions[count][4]);
        
        groupoptions.clearSelection();
    }
    
   
}
