package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.Timer;

public class FrontPage extends JFrame implements ActionListener {

    private String username;
    private JLabel welcomeNote;
    private JTextField fieldForUserName;

    public String getUsername() {
        return username;
    }

    public void displayFrontPage() {
        this.setSize(1250, 700);
        this.setLocation(80, 30);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(null);
        this.getContentPane().setBackground(Color.black);
        this.setTitle("Kitchen Expert");

        welcomeNote = new JLabel("<html>Prepare for the unexpected.<br>The game has begun</html>");
        welcomeNote.setBounds(650, 30, 680, 60);
        welcomeNote.setFont(new Font("dejavu sans mono", Font.BOLD, 25));
        welcomeNote.setForeground(Color.BLUE);
        this.add(welcomeNote);

        // Adjusted image position and size
        ImageIcon i = new ImageIcon(ClassLoader.getSystemResource("icons/frontImage.jpg"));
        Image i2 = i.getImage().getScaledInstance(600, 700, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel imageLabel = new JLabel(i3);
        imageLabel.setBounds(0, 0, 600, 700);
        add(imageLabel);
        

        JLabel loginUsername = new JLabel("Enter Your Name");
        loginUsername.setBounds(700, 250, 200, 25);
        loginUsername.setFont(new Font("dejavu sans mono", Font.BOLD, 22));
        loginUsername.setForeground(Color.BLUE);
        add(loginUsername);

        fieldForUserName = new JTextField();
        fieldForUserName.setBounds(700, 310, 200, 25);
        add(fieldForUserName);

        JButton checkCredentials = new JButton("Login !");
        checkCredentials.setBounds(700, 370, 120, 35);
        checkCredentials.setFont(new Font("dejavu sans mono", Font.BOLD, 20));
        checkCredentials.setBackground(Color.BLUE);
        checkCredentials.setForeground(Color.BLACK);
        checkCredentials.setFocusPainted(false);
        checkCredentials.addActionListener(this);
        add(checkCredentials);

        // Adjusted image position and size
        ImageIcon login = new ImageIcon(ClassLoader.getSystemResource("icons/login1.png"));
        Image login2 = login.getImage().getScaledInstance(249, 202, Image.SCALE_DEFAULT);
        ImageIcon login3 = new ImageIcon(login2);
        JLabel imageLabelLogin = new JLabel(login3);
        imageLabelLogin.setBounds(950, 230, 249, 202);
        add(imageLabelLogin);

        // Flash the welcomeNote using Timer
        Timer timer = new Timer(500, new ActionListener() {
            private boolean isVisible = true;

            @Override
            public void actionPerformed(ActionEvent e) {
                welcomeNote.setVisible(isVisible);
                isVisible = !isVisible;
            }
        });
        timer.start();

        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        username = fieldForUserName.getText();
        this.setVisible(false);
        new Welcome(username);
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new FrontPage().displayFrontPage();
        });
    }
}
