package main;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Score extends JFrame implements ActionListener {
    int score;
   

     Score(int score) {
        this.score = score;
        setBounds(400, 150, 750, 550);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.BLACK);
        setLayout(null);

        if (this.score >=70){
       ImageIcon i1good = new ImageIcon(ClassLoader.getSystemResource("icons/goodScore.png"));
       Image i2 = i1good.getImage().getScaledInstance(300, 250, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(60, 150, 300, 250);
        add(image);
         
        ImageIcon i1good2 = new ImageIcon(ClassLoader.getSystemResource("icons/celebration1.gif"));
       Image ii = i1good2.getImage().getScaledInstance(300, 250, Image.SCALE_DEFAULT);
        ImageIcon iii = new ImageIcon(ii);
        JLabel image1 = new JLabel(iii);
        image1.setBounds(310, 30, 340, 200);
        add(image1);
       
       
        }else if(this.score>=50)
        {
         ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/averageScore.png"));
         Image i2 = i1.getImage().getScaledInstance(300, 250, Image.SCALE_DEFAULT);
         ImageIcon i3 = new ImageIcon(i2);
         JLabel image = new JLabel(i3);
        image.setBounds(60, 120, 350, 250);
        add(image);
     }
        else{
           ImageIcon i1average = new ImageIcon(ClassLoader.getSystemResource("icons/bad-credit-score.jpg"));
         Image i2ave = i1average.getImage().getScaledInstance(300, 250, Image.SCALE_DEFAULT);
         ImageIcon i3ave = new ImageIcon(i2ave);
         JLabel image = new JLabel(i3ave);
        image.setBounds(60, 170, 350, 250);
        add(image);
        
         ImageIcon i1average1 = new ImageIcon(ClassLoader.getSystemResource("icons/disappointed1.gif"));
         Image i2ave2 = i1average1.getImage().getScaledInstance(300, 250, Image.SCALE_DEFAULT);
         ImageIcon i3ave1 = new ImageIcon(i2ave2);
         JLabel image2 = new JLabel(i3ave1);
        image2.setBounds(310, 10, 340, 220);
        add(image2);
        
        
        }
    
        JLabel lblscore = new JLabel("Your score is " + score);
        lblscore.setBounds(410, 260, 300, 30);
        lblscore.setForeground(Color.BLUE);
        lblscore.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(lblscore);

        JButton submit = new JButton("Play Again");
        submit.setBounds(440, 330, 140, 35);
        submit.setBackground(Color.BLUE);
        submit.setForeground(Color.BLACK);
        submit.setFont(new Font("Tahoma", Font.PLAIN, 22));
        submit.addActionListener(this);
        submit.setFocusPainted(false);
        add(submit);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
      FrontPage fp=new FrontPage();
        fp.displayFrontPage();
      
    }
}
