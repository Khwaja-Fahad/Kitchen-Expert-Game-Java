package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Welcome extends JFrame {

    public Welcome(String username) {
        this.getContentPane().setBackground(Color.BLACK);
        this.setLayout(null);
        this.setTitle("Kitchen Expert");
        this.setSize(800, 500);
        this.setLocation(300, 150);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        JLabel welcomeLabel = new JLabel("Welcome to Kitchen Expert Game, Mr. " + username);
        welcomeLabel.setBounds(160, 0, 800, 60);
        welcomeLabel.setFont(new Font("serif", Font.BOLD, 20));
        welcomeLabel.setForeground(Color.YELLOW);
        add(welcomeLabel);

        JLabel selectLevel = new JLabel("Please Select Your Difficulty Level");
        selectLevel.setBounds(210, 150, 800, 60);
        selectLevel.setFont(new Font("serif", Font.BOLD, 20));
        selectLevel.setForeground(Color.BLUE);
        add(selectLevel);

        JButton easy = createLevelButton("Easy", EasyLevel.class, 1);
        JButton medium = createLevelButton("Medium", MediumLevel.class, 2);
        JButton hard = createLevelButton("Hard", HardLevel.class, 3);

        add(easy);
        add(medium);
        add(hard);
    }

    private JButton createLevelButton(String levelName, Class<? extends JFrame> levelClass, int position) {
        JButton button = new JButton(levelName);
        button.setBounds(300, 180 + (60 * position), 120, 40);
        button.setFont(new Font("serif", Font.BOLD, 20));
        button.setBackground(Color.BLACK);
        button.setForeground(Color.BLUE);
        button.setFocusPainted(false);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    JFrame levelFrame = levelClass.getDeclaredConstructor().newInstance();
                    levelFrame.setVisible(true);
                    Welcome.this.setVisible(false);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        
        return button;
        
    }
    
}
